package com.data.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.data.model.User;
import com.data.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository repository;

	@Override
	public boolean add_user(User user) {
		User u = repository.save(user);
		 if(u!=null) {
			 return true;
		 }else {
			 return false;
		 }
	}

	@Override
	public boolean update_user_by_id(User user, int u_id) {
		Optional<User> id = repository.findById(u_id);
		 if(!id.isEmpty()) {
			 User u = id.get();
			 u.setName(user.getName());
			 u.setEmail(user.getEmail());
			 u.setAge(user.getAge());
			 u.setContact(user.getContact());
			 u.setAddress(user.getAddress());
			  repository.save(u);
			  return true;
		 }else {
		   return false;
		 }  
	}

	@Override
	public boolean delete_user_by_id(int u_id) {
		Optional<User> id = repository.findById(u_id);
		 if(!id.isEmpty()) {
			 User user = id.get();
			 repository.delete(user);
			 return true;
		 }else {
		   return false;
		 }
	}

	@Override
	public User get_user_by_id(int u_id) {
	 Optional<User> id = repository.findById(u_id);
	   User user=null;
		if(!id.isEmpty()) {
		   user = id.get(); 
			return user;
		 }else {	 
		   return user;
		 }  
	}

	@Override
	public List<User> get_all_user() {
		List<User> list = repository.findAll();
		 if(!list.isEmpty()) {
			return list;
		 }else {
		   return list;
		 }
	}

}
