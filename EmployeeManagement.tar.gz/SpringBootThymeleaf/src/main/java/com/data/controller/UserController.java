package com.data.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.data.model.User;
import com.data.service.UserServiceImpl;


@Controller
public class UserController {
	
	@Autowired
	private UserServiceImpl service;
	
	@GetMapping("/")
	public String home(Model model) {
		User user=new User();
		model.addAttribute("user", user);
		return "adduser";
	}
	
	@PostMapping("/add")
	public String add_user(@ModelAttribute User user) {
		boolean b = service.add_user(user);
		 if(b) {
			 return "redirect:/get";
		 }else {
			 return "redirect:/";
		 }
	}
	
	@GetMapping("/delete/{u_id}")
	public String delete_user(@PathVariable int u_id) {
		boolean b = service.delete_user_by_id(u_id);
		if(b) {
			 return "redirect:/get";
		 }else {
			 return "error";
		 }
	}
	
	@GetMapping("/get/{u_id}")
	public String get_user(@PathVariable int u_id,Model model) {
	   User user = service.get_user_by_id(u_id);
	    if(user!=null) {
	    	model.addAttribute("user", user);
	    	return "updateuser";
	    }else {
	    	return "error";
	    }
	}
	
	@GetMapping("/get")
	public String get_user_list(Model model) {
		List<User> list = service.get_all_user();
		 if(list!=null && !list.isEmpty()) {
			model.addAttribute("list", list);
			 return "getdata"; 
		 }else {
			 return "redirect:/";
		 }
	}

}
