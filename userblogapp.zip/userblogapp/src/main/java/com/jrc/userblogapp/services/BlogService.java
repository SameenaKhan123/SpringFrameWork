package com.jrc.userblogapp.services;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.jrc.userblogapp.entities.Blog;
import com.jrc.userblogapp.entities.User;
import com.jrc.userblogapp.repo.BlogRepo;

@Service
public class BlogService {
	@Autowired
	BlogRepo blogRepo;
	
	@Autowired
	UserService userService;
	
	public Blog createBlog(int user_id,Blog blog) {
		User user=userService.getUser(user_id);
		blog.setUser(user);
		return blogRepo.save(blog);
	}
	
	public Collection<Blog> getAllBlogs(){
		return blogRepo.findAll();
	}
	
	public Collection<Blog> getUserBlogs(int user_id){
		User user=userService.getUser(user_id);
		return user.getBlogs();
	}
	
	public Blog getUserBlogById(int user_id,int blog_id) {
		User user=userService.getUser(user_id);
		List<Blog> blogs=user.getBlogs();
		Blog blog=blogs.stream().filter((obj-> obj.getBlog_id()==blog_id)).findFirst().
				orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND, "blog with id "+blog_id+" not found"));
		return blog;
	}
	
	public Blog upodateUserBlog(int user_id,int blog_id,Blog newBlog) {
		Blog blog=getUserBlogById(user_id, blog_id);
		blog.setBlog_title(newBlog.getBlog_title());
		blog.setBlog_description(newBlog.getBlog_description());
		return blogRepo.save(blog);
	}
	
	public void deleteBlog(int user_id,int blog_id) {
		blogRepo.deleteByBlogIdAndUserId(blog_id, user_id);
	}

}
