package com.jrc.userblogapp.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.jrc.userblogapp.entities.Blog;

@Repository
public interface BlogRepo extends JpaRepository<Blog, Integer> {
	
	@Modifying
	@Transactional
	@Query(value="DELETE FROM blogs b WHERE b.blog_id = :blogId AND b.user_id = :userId",nativeQuery = true)
	void deleteByBlogIdAndUserId(int blogId, int userId);

}
