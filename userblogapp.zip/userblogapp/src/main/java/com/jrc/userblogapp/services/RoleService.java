package com.jrc.userblogapp.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.jrc.userblogapp.entities.Role;
import com.jrc.userblogapp.repo.RoleRepo;

@Service
public class RoleService {

	@Autowired
	RoleRepo roleRepo;
	
	public Role createRole(Role role) {
		role.setName("ROLE_"+role.getName().toUpperCase());
		Optional<Role> findByName =roleRepo.findByName(role.getName());
		if(findByName.isPresent()) {
			throw new ResponseStatusException(HttpStatus.CONFLICT, "role "+role.getName()+" is already exist");
		}
		return roleRepo.save(role);
	}
}
