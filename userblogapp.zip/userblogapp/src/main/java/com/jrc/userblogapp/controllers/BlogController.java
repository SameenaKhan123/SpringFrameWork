package com.jrc.userblogapp.controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jrc.userblogapp.entities.Blog;
import com.jrc.userblogapp.entities.User;
import com.jrc.userblogapp.services.BlogService;
import com.jrc.userblogapp.services.UserService;

@RestController
@RequestMapping("/blogs")
public class BlogController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	BlogService blogService;
	
	@PostMapping
	public ResponseEntity<Blog> createBlog(@RequestBody Blog blog){
		User user=userService.getCurrentUser();
		return new ResponseEntity<Blog>(blogService.createBlog(user.getId(), blog),HttpStatus.CREATED);
	}
	
	@GetMapping("/all")
	public ResponseEntity<Collection<Blog>> getAllBlogs(){
		return new ResponseEntity<Collection<Blog>>(blogService.getAllBlogs(),HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<Collection<Blog>> getUserBlogs(){
		User user=userService.getCurrentUser();
		return new ResponseEntity<Collection<Blog>>(blogService.getUserBlogs(user.getId()),HttpStatus.OK);
	}
	
	@GetMapping("/{blog_id}")
	public ResponseEntity<Blog>getUserBlogById(@PathVariable int blog_id){
		User user=userService.getCurrentUser();
		return new ResponseEntity<Blog>(blogService.getUserBlogById(user.getId(), blog_id),HttpStatus.OK);
	}
	
	@PutMapping("/{blog_id}")
	public ResponseEntity<Blog> updateUserBlog(@PathVariable int blog_id,@RequestBody Blog newBlog){
		User user=userService.getCurrentUser();
		return new ResponseEntity<Blog>(blogService.upodateUserBlog(user.getId(), blog_id, newBlog),HttpStatus.OK);
	}
	
	@DeleteMapping("/{blog_id}")
	public ResponseEntity deleteBlogById(@PathVariable int blog_id) {
		User user=userService.getCurrentUser();
		blogService.deleteBlog(user.getId(), blog_id);
		return new ResponseEntity(HttpStatus.NO_CONTENT);
	}

}
