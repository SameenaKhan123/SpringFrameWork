package com.jrc.userblogapp.services;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.jrc.userblogapp.dtos.UserRegisterDto;
import com.jrc.userblogapp.entities.Role;
import com.jrc.userblogapp.entities.User;
import com.jrc.userblogapp.repo.RoleRepo;
import com.jrc.userblogapp.repo.UserRepo;

@Service
public class UserService {
//	HashMap<Integer, User> data=new HashMap<>();
//	AtomicInteger atomicInteger=new AtomicInteger();
//	
//	public UserService() {
//		User user1=new User(atomicInteger.incrementAndGet(), "Jitesh", "J@1234");
//		data.put(user1.getId(), user1);
//		
//		User user2=new User(atomicInteger.incrementAndGet(), "abc", "aabb222");
//		data.put(user2.getId(), user2);
//	}
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Autowired
	RoleRepo roleRepo;
	
	public Page<User> getUsers(int page,int size,String sortBy){
		Pageable pageable=PageRequest.of(page, size, Sort.by(sortBy));
		return userRepo.findAll(pageable);
	}
	
	public User createUser(UserRegisterDto userDto) {
	//	user.setId(atomicInteger.incrementAndGet());
		Optional<User> findByUsername=userRepo.findByUsername(userDto.getUsername());
		if(findByUsername.isPresent()) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "user "+userDto.getUsername()+" is already exist");
		}
		
		Set<String> dtoRoles=userDto.getRoles();
		if(dtoRoles==null || dtoRoles.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "At least one role Must be Provided");
		}
		
		Set<Role> checkedRoles=new HashSet<>();
		for(String roleName:dtoRoles) {
			Role checkedRole= roleRepo.findByName("ROLE_"+roleName.toUpperCase())
					.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "role "+roleName+" is not found") );
			checkedRoles.add(checkedRole);
		}
		
		User user=new User();
		user.setUsername(userDto.getUsername());
		user.setRoles(checkedRoles);
		user.setPassword(passwordEncoder.encode(userDto.getPassword()));
		return userRepo.save(user);
	}
	
	public User getUser(int user_id) {
		return userRepo.findById(user_id).orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND,"user with id "+user_id+" not found"));
	}
	
	public User updateUser(int user_id,User user) {
		getUser(user_id);
		user.setId(user_id);
		return userRepo.save(user);
	}
	
	public void deleteUser(int user_id) {
		getUser(user_id);
		userRepo.deleteById(user_id);
	}
	
	public User getCurrentUser() {
		Object principal=SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		User user=null;
		String username;
		if(principal instanceof UserDetails) {
			username=((UserDetails) principal).getUsername();
			user=userRepo.findByUsername(username)
					.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
		}
		else {
			username=principal.toString();
		}
		return user;
	}

}
