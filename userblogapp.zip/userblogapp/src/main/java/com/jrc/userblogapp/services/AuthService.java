package com.jrc.userblogapp.services;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.jrc.userblogapp.entities.User;
import com.jrc.userblogapp.repo.UserRepo;

@Service
public class AuthService implements UserDetailsService {
	
	@Autowired
	private UserRepo userRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user=userRepo.findByUsername(username).
				orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not Found"));
		return new org.springframework.security.core.userdetails.
				User(user.getUsername(), user.getPassword(), user.getRoles().stream().
						map(roles -> new SimpleGrantedAuthority(roles.getName())).collect(Collectors.toList()));
	}

}
