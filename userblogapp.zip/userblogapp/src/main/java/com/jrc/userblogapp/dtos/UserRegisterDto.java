package com.jrc.userblogapp.dtos;

import java.util.Set;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserRegisterDto {

    private String username;
	
	@Size(min = 4,max = 15,message = "password should be between 4-15 characters")
	@NotBlank
	private String password;
	
	private Set<String> roles;
}
